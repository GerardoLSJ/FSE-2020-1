#include <stdio.h>

int main(int argc, char **argv) {
    int i;
    int num;
    
    num = argc;
    
	for(i = 1 ; i <= num + 1 ; i++){
		printf("#%d: FSE2020-1 Fernanda Ortiz & Abril Robles \n",i);
	}

	return 0;
}
